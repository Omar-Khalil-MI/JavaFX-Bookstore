package com.asu.bookstore.gui;

import com.asu.bookstore.models.OrderModel;
import com.asu.bookstore.models.UserModel;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Stage;

public class receiptGUI {
    
    private Scene receiptScene;

    public receiptGUI(UserModel user ,OrderModel order) {
    
        // Create the layout and components for the signup scene
        Button button = new Button("Return Home");
        
        button.setOnMouseClicked(e -> new homeGUI().showHomeScene(button));
        VBox layout = new VBox();
        
        Label lablel = new Label(order.toString());

        lablel.setFont(Font.font(18));
        lablel.autosize();
        
        layout.getChildren().addAll(lablel, button);
        
        Pane pane = new Pane(layout);
        receiptScene = new Scene(pane);
    
    }
    
    
    public Scene getReceiptScene(){
        return receiptScene;
    }
    
    public void showReceiptScene(UserModel user, OrderModel order, Button button) {
        Stage receipt = (Stage)button.getScene().getWindow();
        receipt.close();
        receipt.setScene(receiptScene);
        receipt.setTitle("Bookstore - Receipt");
        receipt.show();
    }
}