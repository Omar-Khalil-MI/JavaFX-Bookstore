package com.asu.bookstore.gui;

import com.asu.bookstore.models.BookModel;
import com.asu.bookstore.main.Main;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

public class deleteGUI {

    private Scene deleteScene;
    private Scene resultScene2;

    public deleteGUI() {
        // Create the layout and components for the add scene
        GridPane layout = new GridPane();
        layout.setPadding(new Insets(20));
        layout.setVgap(10);
    
        TextField name = new TextField();
        Button addButton = new Button("Delete Book");

        // Set up event handlers or actions for the components
        addButton.setOnAction(e -> handleDelete(name.getText().toLowerCase(), addButton));
        
        // Add components to the layout
        layout.add(new Label("Name: "), 0, 0);
        layout.add(name, 1, 0);
        layout.add(addButton, 1, 2);

        // Create the add scene
        deleteScene = new Scene(layout, 400, 370);
        
        StackPane resultLayout2 = new StackPane();// 
        Label resultLabel = new Label();
        resultLayout2.getChildren().add(resultLabel);
        resultScene2 = new Scene(resultLayout2, 300, 100);
    }
    private void handleDelete(String name, Button button) {
        boolean found = false;
        for(BookModel book :  Main.Books){
            if (name.equals(book.getName().toLowerCase())) {
                showResultScene(book.getBookIndex() , button);
                found = true;
                break;
            }
        }
        if (!found) {
            Label label = new Label("Book Not Found!");
            StackPane resultLayout2 = new StackPane(label);
            Stage resultStage = new Stage();
            Scene resutlScene = new Scene(resultLayout2, 300, 100);
            resultStage.setScene(resutlScene);
            resultStage.show();
            }
    }
    
    private void showResultScene(int bookIndex, Button button) {
        Stage resultStage = new Stage();
        Label resultLabel = new Label("Book Deleted!");
        
        for (int i = bookIndex + 1; i < Main.Books.size(); i++) {
            BookModel book = Main.Books.get(i);
            book.setBookIndex(i - 1);
            Main.Books.set(i - 1, book);
        }
        Main.Books.removeLast();
        Main.Inventories.remove(bookIndex);
        
        StackPane resultLayout2 = new StackPane(resultLabel);
        Scene resultScene = new Scene(resultLayout2, 300, 100);
        resultStage.setScene(resultScene);
        resultStage.setTitle("Book Deleted");
        
        new homeGUI().showHomeScene(button);
        resultStage.show();

    }
    
    public void showDeleteScene(Button button) {
        Stage deleteStage = (Stage) button.getScene().getWindow();
        deleteStage.close();
        deleteStage.setScene(deleteScene);
        deleteStage.setTitle("Bookstore - Delete Book Page");
        deleteStage.show();
    }
}
