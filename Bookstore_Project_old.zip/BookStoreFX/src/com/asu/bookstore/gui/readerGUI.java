package com.asu.bookstore.gui;

import com.asu.bookstore.models.AddressModel;
import com.asu.bookstore.models.ReaderModel;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

public class readerGUI {

    private Scene readerScene;
    private Scene resultScene2;

    
    public readerGUI(ReaderModel user) {
        
        // Create the layout and components for the signup scene
        GridPane layout = new GridPane();
        layout.setPadding(new Insets(20));
        layout.setVgap(10);

        TextField emailField = new TextField();
        TextField usernameField = new TextField(user.getUserName());
        TextField passwordField = new TextField(user.getPassword());
        TextField phoneNumberField = new TextField(user.getPhoneNumber());
        TextField cityField = new TextField(user.getAddress().getCity());
        TextField ZIPcodeField = new TextField(user.getAddress().getPostal_Code());
        Button updateButton = new Button("Update");

        // Set up event handlers or actions for the components
        updateButton.setOnAction(e -> handleUpdate(emailField.getText(), usernameField.getText(), passwordField.getText(), phoneNumberField.getText(),cityField.getText(),ZIPcodeField.getText(), updateButton));
        
        // Add components to the layout
        layout.add(new Label("Email:"), 0, 0);
        layout.add(emailField, 1, 0);
        layout.add(new Label("Username:"), 0, 1);
        layout.add(usernameField, 1, 1);
        layout.add(new Label("Password:"), 0, 2);
        layout.add(passwordField, 1, 2);
        layout.add(new Label("Phone Number:"), 0, 3);
        layout.add(phoneNumberField, 1, 3);
        layout.add(new Label("City:"), 0, 4);
        layout.add(cityField, 1, 4);
        layout.add(new Label("ZIP code:"), 0, 5);
        layout.add(ZIPcodeField, 1, 5);
        layout.add(updateButton, 1, 7);

        // Create the signup scene
        readerScene = new Scene(layout, 400, 370);
        
        StackPane resultLayout2 = new StackPane();// 
        Label resultLabel = new Label();
        resultLayout2.getChildren().add(resultLabel);
        resultScene2 = new Scene(resultLayout2, 300, 100);
    }

    public Scene getScene() {
        return readerScene;
    }
    
    
    private void handleUpdate(String email, String username, String password, String phoneNumber,String city, String ZIPcode, Button button) {
        Stage resultStage = new Stage();
        Label resultLabel = new Label();
        
        new homeGUI().showHomeScene(button);
        resultLabel.setText("Data Updated Successfully");
        
        StackPane resultLayout2 = new StackPane(resultLabel);
        Scene resultScene = new Scene(resultLayout2, 300, 100);

        resultStage.setScene(resultScene);
        resultStage.setTitle("Update Result");
        resultStage.show();
        
        AddressModel a = new AddressModel(city, ZIPcode);
        ((ReaderModel)(homeGUI.getInSession())).setAddress(a);
        ((ReaderModel)(homeGUI.getInSession())).setMail(email);
        ((ReaderModel)(homeGUI.getInSession())).setPassword(password);
        ((ReaderModel)(homeGUI.getInSession())).setUserName(username);
        ((ReaderModel)(homeGUI.getInSession())).setPhoneNumber(phoneNumber);
    }
        
}
