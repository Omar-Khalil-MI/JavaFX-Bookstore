package com.asu.bookstore.gui;

import com.asu.bookstore.models.BookModel;
import com.asu.bookstore.models.InventoryModel;
import com.asu.bookstore.main.Main;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

public class addGUI {

    private Scene addScene;
    private Scene resultScene2;

    public addGUI() {
        // Create the layout and components for the add scene
        GridPane layout = new GridPane();
        layout.setPadding(new Insets(20));
        layout.setVgap(10);
    
        TextField name = new TextField();
        TextField author = new TextField();
        TextField price = new TextField();
        TextField publisherName = new TextField();
        TextField category = new TextField();
        TextField amount = new TextField();
        TextField isbn = new TextField();
        Button addButton = new Button("Add Book");

        // Set up event handlers or actions for the components
        addButton.setOnAction(e -> showResultScene(name.getText(), author.getText(), price.getText(),
                publisherName.getText(),category.getText(),isbn.getText(), amount.getText(), addButton));
        
        // Add components to the layout
        layout.add(new Label("Name:"), 0, 0);
        layout.add(name, 1, 0);
        layout.add(new Label("Author:"), 0, 1);
        layout.add(author, 1, 1);
        layout.add(new Label("Price:"), 0, 2);
        layout.add(price, 1, 2);
        layout.add(new Label("Publisher:"), 0, 3);
        layout.add(publisherName, 1, 3);
        layout.add(new Label("Category:"), 0, 4);
        layout.add(category, 1, 4);
        layout.add(new Label("Amount:"), 0, 5);
        layout.add(amount, 1, 5);
        layout.add(new Label("ISBN:"), 0, 6);
        layout.add(isbn, 1, 6);
        layout.add(addButton, 1, 7);

        // Create the add scene
        addScene = new Scene(layout, 400, 370);
        
        StackPane resultLayout2 = new StackPane();// 
        Label resultLabel = new Label();
        resultLayout2.getChildren().add(resultLabel);
        resultScene2 = new Scene(resultLayout2, 300, 100);
    }
    private void showResultScene(String name, String author,
            String price, String publisher,String category, String isbn, String amount, Button button) {
        Stage resultStage = new Stage();
        Label resultLabel = new Label();
        resultLabel.setText("Book added!");
        
        StackPane resultLayout2 = new StackPane(resultLabel);
        Scene resultScene = new Scene(resultLayout2, 300, 100);
        resultStage.close();
        resultStage.setScene(resultScene);
        resultStage.setTitle("Book Added");
        
        BookModel b = new BookModel(name, author, publisher, Double.parseDouble(price),
                category, isbn);
        InventoryModel i = new InventoryModel(name, Integer.parseInt(amount));
        Main.Books.add(b);
        Main.Inventories.add(i);
        new homeGUI().showHomeScene(button);
        resultStage.show();

    }
    
    public void showAddScene(Button button) {
        Stage addStage = (Stage) button.getScene().getWindow();
        addStage.close();
        addStage.setScene(addScene);
        addStage.setTitle("Bookstore - Add Book Page");
        addStage.show();
    }
}
