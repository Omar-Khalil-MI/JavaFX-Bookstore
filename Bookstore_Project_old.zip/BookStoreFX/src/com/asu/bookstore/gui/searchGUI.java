package com.asu.bookstore.gui;

import com.asu.bookstore.models.BookModel;
import com.asu.bookstore.main.Main;
import com.asu.bookstore.models.UserModel;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Stage;

public class searchGUI {
private Scene searchScene;
    private static boolean loggedIn = false; // Flag to track login status
    public static void setLoginStatus(boolean status){loggedIn=status;}
    public static boolean getLoginStatus(){return loggedIn;}
    private static UserModel insession;
    public static void setInSession(UserModel user) {
        insession = user;
    }
    
    public static UserModel getInSession(){return insession;}

        public searchGUI(String s) {

            VBox layout = new VBox(20);
            layout.setPadding(new Insets(30, 20, 20, 30));

            HBox searchBox = new HBox();
            TextField searchField = new TextField("Search");
            Button searchButton = new Button("Search");

            Button homeButton = new Button("Return");
            homeButton.setOnAction(e -> new homeGUI().showHomeScene(homeButton));
            searchBox.getChildren().addAll(searchField, searchButton, homeButton);

            
            
            layout.getChildren().add(searchBox);
            searchButton.setOnAction(e -> new searchGUI(searchField.getText()).showSearchScene(insession, searchButton));


            layout.getChildren().add(createColumn(s, insession));

            
            ScrollPane scroll = new ScrollPane(layout);
            searchScene = new Scene(scroll);

        }
        
    public void showSearchScene(UserModel insession , Button button){

        Stage searchStage = (Stage) button.getScene().getWindow();
        searchStage.close();
        searchStage.setScene(searchScene);
        searchStage.setTitle("Bookstore - Search");
        searchStage.show();
    
    }
    
        private VBox createColumn(String s, UserModel user) {
        VBox column = new VBox(20);
        HBox currentRow = new HBox(100);
        s = s.toLowerCase();
        for (BookModel book : Main.Books) {
            if (Main.Inventories.get(book.getBookIndex()).getAmount() > 0
                    && ((book.getName().toLowerCase()).contains(s))) {
                printBook(book, user, currentRow);

                if (currentRow.getChildren().size() == 3) {
                    // Add the current row to the column and create a new row
                    column.getChildren().add(currentRow);
                    currentRow = new HBox(100);
                }
            }
        }
        // Add the last row if it's not empty
        if (!currentRow.getChildren().isEmpty()) {
            column.getChildren().add(currentRow);
        }

        return column;
        
        }
    
    public void printBook(BookModel book, UserModel user, HBox column) {
        Button button = new Button("Buy Book");

        Label label = new Label("Name: " + book.getName() + "\nAuthor: " + book.getAuthor() + "\nCategory: "
                + book.getCategory() + "\n" + "Publisher: " + book.getPublisherName()
                + "\nPrice: $" + String.valueOf(book.getPrice()));

        label.setFont(Font.font(18));

        Image image = new Image(Main.PATH + book.getImage() + ".jpg");

        ImageView view = new ImageView(image);
        view.setFitHeight(200);
        view.setFitWidth(150);

        VBox bookBox = new VBox(10);
        bookBox.setAlignment(Pos.CENTER); // Center the content
        bookBox.setMaxWidth(200); // Set a maximum width for consistency
        bookBox.getChildren().addAll(view, button, label);

        button.setOnMouseClicked(e -> new bookGUI(user, book).showBookScene(user, book, button));
        column.getChildren().add(bookBox);
    }
}