package com.asu.bookstore.gui;

import com.asu.bookstore.models.AddressModel;
import com.asu.bookstore.main.Main;
import com.asu.bookstore.models.ReaderModel;
import com.asu.bookstore.models.UserModel;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

public class SignupGUI {

    private Scene signupScene;
    private Scene resultScene2;
    private boolean validsignup=false;

    public SignupGUI() {
        // Create the layout and components for the signup scene
        GridPane layout = new GridPane();
        layout.setPadding(new Insets(20));
        layout.setVgap(10);

        TextField emailField = new TextField();
        TextField usernameField = new TextField();
        PasswordField passwordField = new PasswordField();
        TextField phoneNumberField = new TextField();
        TextField cityField = new TextField();
        TextField ZIPcodeField = new TextField();
        Button signupButton = new Button("Sign up");

        // Set up event handlers or actions for the components
        signupButton.setOnAction(e -> handleSignup(emailField.getText(), usernameField.getText(), passwordField.getText(),
                phoneNumberField.getText(),cityField.getText(),ZIPcodeField.getText(), signupButton));
        
        // Add components to the layout
        layout.add(new Label("Email:"), 0, 0);
        layout.add(emailField, 1, 0);
        layout.add(new Label("Username:"), 0, 1);
        layout.add(usernameField, 1, 1);
        layout.add(new Label("Password:"), 0, 2);
        layout.add(passwordField, 1, 2);
        layout.add(new Label("Phone Number:"), 0, 3);
        layout.add(phoneNumberField, 1, 3);
        layout.add(new Label("City:"), 0, 4);
        layout.add(cityField, 1, 4);
        layout.add(new Label("ZIP code:"), 0, 5);
        layout.add(ZIPcodeField, 1, 5);
        layout.add(signupButton, 1, 6);

        // Create the signup scene
        signupScene = new Scene(layout, 400, 370);
        
        StackPane resultLayout2 = new StackPane();// 
        Label resultLabel = new Label();
        resultLayout2.getChildren().add(resultLabel);
        resultScene2 = new Scene(resultLayout2, 300, 100);
    }

    public Scene getScene() {
        return signupScene;
    }

    private void handleSignup(String email, String username, String password, String phoneNumber,String city, String ZIPcode, Button button) {
        boolean found=false;
        boolean validnum=true;
        boolean validpass=true;
        for(int i = 0;i < Main.Users.size(); i++){
            UserModel user = Main.Users.get(i);
            if (username.equals(user.getUserName())) {
                found = true;
            }
        }
        if( phoneNumber.length() != 11 ) validnum = false;
        else{
            for(int i = 0;i < phoneNumber.length(); i++){
                if(phoneNumber.charAt(i)<48 || phoneNumber.charAt(i)>57) validnum=false;
            }
        }    
        if(password.length()<5) validpass=false;
        
        showResultScene(found,validnum,validpass, email,username,password,phoneNumber,city,ZIPcode, button);
        found=false; //reinitiallize flags to avoid errors
        validnum=true;
        validpass=true;
    }
    
    private void showResultScene(boolean found, boolean validnum, boolean validpass, String email, String username,
            String password, String phoneNumber,String city, String ZIPcode, Button button) {
        Stage resultStage = (Stage) button.getScene().getWindow();
        Label resultLabel = new Label();

        if (found) {
            resultLabel.setText("Username taken");
        } else {
            if (!validnum) {
                resultLabel.setText("invalid phone number!");
            } else if(!validpass){
                resultLabel.setText("password must contain more than 4 digits");
            }
            else{ resultLabel.setText("Signed up Successfully!");
                validsignup=true;
            }
        }

        StackPane resultLayout2 = new StackPane(resultLabel);
        Scene resultScene = new Scene(resultLayout2, 300, 100);
        resultStage.close();
        resultStage.setScene(resultScene);
        resultStage.setTitle("Signup Result");
        resultStage.show();
        if (validsignup) {
            AddressModel a = new AddressModel(city, ZIPcode);
            Main.Users.add(new ReaderModel(false, username, email, password, a, phoneNumber));
            homeGUI.setLoginStatus(true);
            homeGUI.setInSession(Main.Users.getLast());
        validsignup = false;
        }

    }
        
}
