package com.asu.bookstore.gui;

import com.asu.bookstore.models.BookModel;
import com.asu.bookstore.main.Main;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

public class editGUI {

    private Scene editScene;
    private Scene resultScene2;

    
    public editGUI(BookModel book) {
        
        // Create the layout and components for the signup scene
        GridPane layout = new GridPane();
        layout.setPadding(new Insets(20));
        layout.setVgap(10);

        TextField name = new TextField(book.getName());
        TextField author = new TextField(book.getAuthor());
        TextField publisher = new TextField(book.getPublisherName());
        TextField price = new TextField(String.valueOf(book.getPrice()));
        TextField amount = new TextField(String.valueOf(Main.Inventories.get(book.getBookIndex()).getAmount()));
        TextField category = new TextField(book.getCategory());
        TextField isbn = new TextField(book.getIsbn());
        Button updateButton = new Button("Update");

        // Set up event handlers or actions for the components
        updateButton.setOnAction(e -> handleEdit(book, name.getText(), author.getText(), publisher.getText(), price.getText(),category.getText(),isbn.getText(), amount.getText(), updateButton));
        
        // Add components to the layout
        layout.add(new Label("Name: "), 0, 0);
        layout.add(name, 1, 0);
        layout.add(new Label("Author: "), 0, 1);
        layout.add(author, 1, 1);
        layout.add(new Label("Publisher: "), 0, 2);
        layout.add(publisher, 1, 2);
        layout.add(new Label("Price: "), 0, 3);
        layout.add(price, 1, 3);
        layout.add(new Label("Amount: "), 0, 6);
        layout.add(amount, 1, 6);
        layout.add(new Label("Category: "), 0, 7);
        layout.add(category, 1, 7);
        layout.add(new Label("ISBN : "), 0, 8);
        layout.add(isbn, 1, 8);
        layout.add(updateButton, 1, 9);

        // Create the signup scene
        editScene = new Scene(layout, 400, 370);
        
        StackPane resultLayout2 = new StackPane();// 
        Label resultLabel = new Label();
        resultLayout2.getChildren().add(resultLabel);
        resultScene2 = new Scene(resultLayout2, 300, 100);
    }

    public Scene getScene() {
        return editScene;
    }
    
    
    private void handleEdit(BookModel book,String name, String author, String publisher, String price,String category, String isbn, String amount, Button button) {
        Stage resultStage = new Stage();
        Label resultLabel = new Label();
        
        Main.Inventories.get(book.getBookIndex()).setAmount(Integer.parseInt(amount));
        Main.Books.get(book.getBookIndex()).setName(name);
        Main.Books.get(book.getBookIndex()).setAuthor(author);
        Main.Books.get(book.getBookIndex()).setPublisherName(publisher);
        Main.Books.get(book.getBookIndex()).setPrice(Double.parseDouble(price));
        Main.Books.get(book.getBookIndex()).setCategory(category);
        Main.Books.get(book.getBookIndex()).setIsbn(isbn);
        
        new homeGUI().showHomeScene(button);
        resultLabel.setText("Data Updated Successfully");
        
        StackPane resultLayout2 = new StackPane(resultLabel);
        Scene resultScene = new Scene(resultLayout2, 300, 100);

        resultStage.setScene(resultScene);
        resultStage.setTitle("Update Book");
        resultStage.show();
    }
    public void showEditScene(Button button) {
        Stage editStage = (Stage) button.getScene().getWindow();
        editStage.close();
        editStage.setScene(editScene);
        editStage.setTitle("Bookstore - Edit Book Page");
        editStage.show();
    }   
}
