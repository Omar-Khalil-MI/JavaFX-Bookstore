package com.asu.bookstore.gui;

import com.asu.bookstore.models.BookModel;
import com.asu.bookstore.main.Main;
import com.asu.bookstore.models.ReaderModel;
import com.asu.bookstore.models.UserModel;
import javafx.event.ActionEvent;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javafx.geometry.Pos;
import javafx.scene.layout.StackPane;

public class homeGUI{

    private Scene homeScene;
    private static boolean loggedIn = false; // Flag to track login status
    public static void setLoginStatus(boolean status){loggedIn=status;}
    public static boolean getLoginStatus(){return loggedIn;}
    private static UserModel insession;
    public static void setInSession(UserModel user) {
        insession = user;
    }
    public static UserModel getInSession(){return insession;}
    
            
    public homeGUI() {
        VBox layout = new VBox(20);
        layout.setPadding(new Insets(30, 20, 20, 30));

        HBox searchBox = new HBox();
        TextField searchField = new TextField();
        Button searchButton = new Button("Search");
        searchBox.getChildren().addAll(searchField, searchButton);
        layout.getChildren().add(searchBox);
        
        searchButton.setOnAction(e -> new searchGUI(searchField.getText()).showSearchScene(insession, searchButton));

        HBox buttonBox = new HBox(20);
        buttonBox.getChildren().add(createLoginButton());
        buttonBox.getChildren().add(createViewProfileButton(insession));
        buttonBox.getChildren().add(createLogoutButton());
        layout.getChildren().add(buttonBox);

        if (loggedIn && insession.getIsAdmin()) {
            HBox adminBox = new HBox(20);
            Button add = new Button("Add Book");
            add.setOnMouseClicked(e -> new addGUI().showAddScene(add));
            Button delete = new Button("Delete Book");
            delete.setOnMouseClicked(e -> new deleteGUI().showDeleteScene(delete));
            adminBox.getChildren().addAll(add, delete);
            layout.getChildren().add(adminBox);
        }
        
        layout.getChildren().add(createColumn(insession));
        
        ScrollPane scroll = new ScrollPane(layout);
        homeScene = new Scene(scroll);
    }
    
    private VBox createColumn(UserModel user) {
        VBox column = new VBox(20);

        HBox currentRow = new HBox(100);
        int z = 0;
        for (BookModel book : Main.Books) {
            if ( loggedIn && insession.getIsAdmin()) 
                z = -1;
            if (Main.Inventories.get(book.getBookIndex()).getAmount() > z) {
                printBook(book, user, currentRow);

                if (currentRow.getChildren().size() == 3) {
                    // Add the current row to the column and create a new row
                    column.getChildren().add(currentRow);
                    currentRow = new HBox(100);
                }
            }
        }

        // Add the last row if it's not empty
        if (!currentRow.getChildren().isEmpty()) {
            column.getChildren().add(currentRow);
        }

        return column;
    }

    public void printBook(BookModel book, UserModel user, HBox column) {
        Button buyButton = new Button("Buy Book");
        
        Label label = new Label("Name: " + book.getName() + "\nAuthor: " + book.getAuthor() + "\nCategory: "
                + book.getCategory() + "\n" + "Publisher: " + book.getPublisherName()
                + "\nPrice: $" + String.valueOf(book.getPrice()));

        label.setFont(Font.font(18));

        Image image = new Image(Main.PATH + book.getImage() + ".jpg");

        ImageView view = new ImageView(image);
        view.setFitHeight(200);
        view.setFitWidth(150);
        Button editButton = new Button("Edit Book");
        HBox buttonBox = new HBox();
        buttonBox.setPadding(new Insets(0,0,0,30));
        buttonBox.getChildren().add(buyButton);
        if (loggedIn && insession.getIsAdmin()) {
            editButton.setOnMouseClicked(e -> new editGUI(book).showEditScene(editButton));
            buttonBox.getChildren().add(editButton);
        }
        
        VBox bookBox = new VBox(10);
        bookBox.setAlignment(Pos.CENTER); // Center the content
        bookBox.setMaxWidth(200); // Set a maximum width for consistency
        bookBox.getChildren().addAll(view, buttonBox, label);

        buyButton.setOnMouseClicked(e -> new bookGUI(user, book).showBookScene(user, book, buyButton));
        column.getChildren().add(bookBox);
    }

    private Button createLoginButton() {
        Button loginButton = new Button("Login");
        loginButton.setOnAction(event -> openLoginGUI(event, loggedIn, loginButton));
        return loginButton;
    }
    
    private Button createLogoutButton(){
        Button logoutButton=new Button("Logout");
        logoutButton.setOnAction(event -> openLogoutGUI(event, loggedIn, logoutButton));
        return logoutButton;
    }

    private Button createViewProfileButton(UserModel user) {
        Button viewProfileButton = new Button("View Profile");
         viewProfileButton.setOnAction(event -> openReaderGUI(event, user, loggedIn, viewProfileButton));
        return viewProfileButton;
    }

    public Scene getHomeScene() {
        return homeScene;
    }

    
    public void showHomeScene(Button button) {
        Stage homeStage = (Stage) button.getScene().getWindow();
        homeStage.close();
        homeStage.setScene(homeScene);
        homeStage.setTitle("Bookstore - Home Page");
        homeStage.show();
    }

    public void openLoginGUI(ActionEvent event, boolean x, Button button) {
        if(x){
            Stage resultStage = new Stage();
            Label resultLabel = new Label();
            resultLabel.setText("already logged in");
            StackPane resultLayout2 = new StackPane(resultLabel);
            Scene resultScene = new Scene(resultLayout2, 300, 100);

            resultStage.setScene(resultScene);
            resultStage.setTitle("Login Result");
            resultStage.show();
        }
        else{
            LoginGUI loginScene = new LoginGUI();
            Stage loginStage = (Stage) button.getScene().getWindow();
            loginStage.close();
            loginStage.setScene(loginScene.getLoginScene());
            loginStage.setTitle("Bookstore - Login");
            loginStage.show();
        }
    }
    public void openReaderGUI(ActionEvent event,UserModel insession, boolean x, Button button){
        if(!x){
        Stage resultStage = new Stage();
        Label resultLabel = new Label();
        resultLabel.setText("Please Login");
        StackPane resultLayout2 = new StackPane(resultLabel);
        Scene resultScene = new Scene(resultLayout2, 300, 100);

        resultStage.setScene(resultScene);
        resultStage.setTitle("profile Result");
        resultStage.show();
        }
        else{
        readerGUI profileScene = new readerGUI((ReaderModel)insession);
        Stage loginStage = (Stage) button.getScene().getWindow();
        loginStage.close();
        loginStage.setScene(profileScene.getScene());
        loginStage.setTitle("Bookstore - Profile");
        loginStage.show();
                }
    }
    
    public void openLogoutGUI(ActionEvent event,boolean x, Button button){
        Stage resultStage = new Stage();
        Label resultLabel = new Label();

        if (!x) {
            resultLabel.setText("already logged out");
        } else {
            loggedIn=false;
            insession = null;
            resultLabel.setText("Logged out Successfully");
        }
        new homeGUI().showHomeScene(button);
        StackPane resultLayout2 = new StackPane(resultLabel);
        Scene resultScene = new Scene(resultLayout2, 300, 100);
        resultStage.setScene(resultScene);
        resultStage.setTitle("Logout Result");
        resultStage.show();
    }
}
