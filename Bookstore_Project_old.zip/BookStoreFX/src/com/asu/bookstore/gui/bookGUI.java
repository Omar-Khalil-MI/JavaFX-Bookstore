package com.asu.bookstore.gui;

import com.asu.bookstore.models.BookModel;
import com.asu.bookstore.main.Main;
import com.asu.bookstore.models.OrderModel;
import com.asu.bookstore.models.UserModel;
import java.time.LocalDate;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.ImageView;
import javafx.scene.image.Image;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javafx.scene.layout.StackPane;

public class bookGUI {
    
    private Scene bookScene;
    
    public bookGUI(UserModel user, BookModel book){
        // Create the layout and components for the signup scene
        Button buyButton = new Button("Buy Book");
        Button cancelButton = new Button("Cancel");
        
        cancelButton.setOnMouseClicked(e -> new homeGUI().showHomeScene(buyButton));
        buyButton.setOnMouseClicked(e -> {
            OrderModel order = new OrderModel(user.getUserName(), book.getPrice(), LocalDate.now(), book.getName());
            order.confirmOrder(book);
            new receiptGUI(user, order).showReceiptScene(user, order, buyButton);
        });
        VBox layout = new VBox();
        
        Label lablel = new Label("Name: " + book.getName() + "\nAuthor: " + book.getAuthor() + "\nCateogry: "
                + book.getCategory() + "\n" + "Publisher: " + book.getPublisherName()
                + "\nPrice: $" + String.valueOf(book.getPrice() + "\nISBN: " + book.getIsbn() + "\n\n\n"));

        lablel.setFont(Font.font(18));
        lablel.autosize();
        Image image = new Image(Main.PATH + book.getImage() + ".jpg");

        ImageView view = new ImageView(image);
        view.setFitHeight(450);
        view.setFitWidth(350);
        
        GridPane gPane = new GridPane();
        gPane.add(buyButton, 0, 0);
        gPane.add(cancelButton, 1, 0);
        layout.getChildren().addAll(view, lablel, gPane);
        
        Pane pane = new Pane(layout);
        bookScene = new Scene(pane);
    }
    
    public Scene getBookScene() {
        return bookScene;
    }
    
    public void showBookScene(UserModel user, BookModel book, Button button) {
        if(!homeGUI.getLoginStatus()){
            Stage resultStage = new Stage();
            Label resultLabel = new Label();
            resultLabel.setText("Please Login");
            StackPane resultLayout2 = new StackPane(resultLabel);
            Scene resultScene = new Scene(resultLayout2, 300, 100);

            resultStage.setScene(resultScene);
            resultStage.setTitle("profile Result");
            resultStage.show();
        }
        else{
            Stage bookStage = (Stage) button.getScene().getWindow();
            bookStage.close();
            bookStage.setScene(bookScene);
            bookStage.setTitle("Bookstore - " + book.getName());
            bookStage.show();
            }        
    }
    
    
}
