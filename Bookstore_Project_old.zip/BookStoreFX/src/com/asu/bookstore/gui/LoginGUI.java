package com.asu.bookstore.gui;

import com.asu.bookstore.main.Main;
import com.asu.bookstore.models.UserModel;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

public class LoginGUI {

    private Scene loginScene;
    private Scene resultScene;
    public boolean temp=false;

    public LoginGUI() {
        GridPane layout = new GridPane(); // grid layout divides the layout area into rows and columns.You can place nodes in specific cells of the grid
        layout.setPadding(new Insets(20));//padding means the space between the content of the container and the container's edges. if removed the text/fields will be in the corner
        layout.setVgap(10);// vertical gap between rows of the grid

        TextField usernameField = new TextField();
        PasswordField passwordField = new PasswordField();
        Button loginButton = new Button("Login");
        Label firstTimeLabel = new Label("First time?");
        Hyperlink signupLink = new Hyperlink("Signup");

        Button cancelButton = new Button("Cancel");
        
        cancelButton.setOnMouseClicked(e -> new homeGUI().showHomeScene(cancelButton));
        
        loginButton.setOnAction(e -> handleLogin(usernameField.getText(), passwordField.getText(),loginButton));//event when button presses (handleLogin)

        signupLink.setOnAction(e -> showSignupScene());// event when link pressed

        HBox buttonBox = new HBox(20);
        buttonBox.getChildren().addAll(loginButton,cancelButton);
        
        // Add components to the layout
        layout.add(new Label("Username:  "), 0, 0); //el origin
        layout.add(usernameField, 1, 0);// by2asem el grid le cells w y7ot f kol cell(x,y) 7aga (label, field, button, link....)
        layout.add(new Label("Password:  "), 0, 1);
        layout.add(passwordField, 1, 1);
        layout.add(buttonBox, 1, 2);
        layout.add(firstTimeLabel, 0, 3);
        layout.add(signupLink, 1, 3);

        loginScene = new Scene(layout, 400, 200);

        StackPane resultLayout = new StackPane();// el feha welcome back aw incorrect password w kda
        Label resultLabel = new Label();
        resultLayout.getChildren().add(resultLabel);
        resultScene = new Scene(resultLayout, 300, 100);
    }

    public Scene getLoginScene() {
        return loginScene;
    }

    private void showSignupScene() {
    // Create a new stage for the signup scene
    Stage signupStage = new Stage();

    // Create the signup scene
    SignupGUI signup = new SignupGUI();
    Scene signupScene = signup.getScene();

    // Set the scene for the signup stage
    signupStage.setScene(signupScene);

    // Set the title for the signup stage
    signupStage.setTitle("Bookstore Application - Signup");

    // Show the signup stage
    signupStage.show();
}


    private void handleLogin(String enteredUsername, String enteredPassword, Button button) {
        boolean valid = false;//valid user name if it doesn't exist in database
        boolean found = false;

        for(int i = 0; i < Main.Users.size(); i++){
            UserModel user = Main.Users.get(i);
            if (enteredUsername.equals(user.getUserName())) {
                found = true;
                if (enteredPassword.equals(user.getPassword())) {
                    valid = true;
                }
                break;
            }
        }
        showResultScene(found, valid,enteredUsername, button);
    }
    private void showResultScene(boolean found, boolean valid, String s, Button button) {
        Stage resultStage = new Stage();
        Label resultLabel = new Label();

        if (!found) {
            resultLabel.setText("Username not found");
        } else {
            if (valid) {
                resultLabel.setText("Welcome back!");
                homeGUI.setLoginStatus(true);
                for(int i=0;i<Main.Users.size();i++){
                    if(s.equals(Main.Users.get(i).getUserName())){
                        homeGUI.setInSession(Main.Users.get(i));
                        new homeGUI().showHomeScene(button);
                        break;
                    }
                }
            } else {
                resultLabel.setText("incorrect password");
            }
        }

        StackPane resultLayout = new StackPane(resultLabel);
        resultScene = new Scene(resultLayout, 300, 100);
        resultStage.setScene(resultScene);
        resultStage.setTitle("Login Result");
        resultStage.show();
    }
}
