package com.asu.bookstore.models;
import com.asu.bookstore.main.Main;
import java.util.ArrayList;

public class ReaderModel extends UserModel {
    private String phoneNumber;
    private int readerID;
  
    public ReaderModel(boolean isAdmin, String userName, String mail, String password, AddressModel address, String phoneNumber) {
        super(isAdmin, userName, mail, password, address);
        readerID = Main.Users.size();
        this.phoneNumber = phoneNumber;
        this.address = address;
    }


    public ArrayList<OrderModel> viewOrders() {
        ArrayList<OrderModel> list = new ArrayList<>();
        for (int i = 0; i < Main.Orders.size(); i++) {
            if (Main.Orders.get(i).getReaderName().equals(userName)) 
                list.add(Main.Orders.get(i));
        }
        return list;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String s){phoneNumber=s;}
    
    @Override
    public String toString() {
        super.toString();
        return "Reader{" + "phoneNumber=" + phoneNumber + ", readerID=" + readerID + '}';
    }

    public int getReaderID() {
        return readerID;
    }

    public void setReaderID(int readerID) {
        this.readerID = readerID;
    }

    public boolean isIsAdmin() {
        return isAdmin;
    }

    public void setIsAdmin(boolean isAdmin) {
        this.isAdmin = isAdmin;
    }

    @Override
    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    @Override
    public String getMail() {
        return mail;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }

    @Override
    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public AddressModel getAddress() {
        return address;
    }

    public void setAddress(AddressModel address) {
        this.address = address;
    }
    
}