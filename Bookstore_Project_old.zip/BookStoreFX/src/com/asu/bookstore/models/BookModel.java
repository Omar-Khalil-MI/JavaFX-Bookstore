package com.asu.bookstore.models;

import com.asu.bookstore.main.Main;

public class BookModel {

    private String name;

    private String author;

    private String publisherName;

    private double price;

    private String category;
    
    private String image;

    private String isbn;
    
    private int bookIndex;

    public BookModel(String name, String author, String publisher, double price, String category, String isbn) {
        this.name = name;
        this.author = author;
        publisherName = publisher;
        this.price = price;
        this.category = category;
        this.isbn = isbn;
        bookIndex = Main.Books.size();
        image = "no-image";
    }

    public BookModel(String name, String author, String publisher, double price, String category, String isbn, String image) {
        this(name, author, publisher, price, category, isbn);
        this.image = image;
    }

    @Override
    public String toString() {
        return "BookModel{" + "name=" + name + ", author=" + author + ", publisherName=" + publisherName + ", price=" + price + ", category=" + category + ", image=" + image + ", isbn=" + isbn + ", bookIndex=" + bookIndex + '}';
    }

    public String getImage() {
        return image;
    }
    
    
    public int getBookIndex() {
        return bookIndex;
    }

    public String getName() {
        return name;
    }

    public String getAuthor() {
        return author;
    }

    public String getPublisherName() {
        return publisherName;
    }

    public double getPrice() {
        return price;
    }

    public String getCategory() {
        return category;
    }

    public String getIsbn() {
        return isbn;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public void setPublisherName(String publisherName) {
        this.publisherName = publisherName;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public void setBookIndex(int bookIndex) {
        this.bookIndex = bookIndex;
    }
    
    
}
