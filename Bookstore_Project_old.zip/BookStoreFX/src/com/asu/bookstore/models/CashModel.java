package com.asu.bookstore.models;
public class CashModel extends PaymentModel {

    private double cashTendered;
    
    public CashModel (ReaderModel reader, OrderModel order, double amount, double cashTendered) {
        super(reader, order, amount);
        this.cashTendered = cashTendered;
    }

    
    @Override
    public void processPayment() {
        // Process Cash Payment
        System.out.println("Processing Cash Payment...");
        // Cash payment processing
        if (cashTendered < getAmount())
            System.out.println("Not enough money !");
        else System.out.println("Cash Payment Processed successfully.");
    }

    
    public double getCashTendered() {
        return cashTendered;
    }
}
