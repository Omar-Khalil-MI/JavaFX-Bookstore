package com.asu.bookstore.models;
public abstract class UserModel {

    protected boolean isAdmin;
    
    protected String userName;

    protected String mail;

    protected String password;

    protected AddressModel address;

    
    public UserModel(boolean isAdmin, String userName, String mail, String password, AddressModel address) {
        this.isAdmin = isAdmin;
        this.userName = userName;
        this.mail = mail;
        this.password = password;
        this.address = address;
    }

    public boolean getIsAdmin() {
        return isAdmin;
    }

    public String getUserName() {
        return userName;
    }

    public String getMail() {
        return mail;
    }

    public String getPassword() {
        return password;
    }

    public AddressModel getAddress() {
        return address;
    }
    
    @Override
    public String toString() {
        return "User{" + "isAdmin=" + isAdmin + ", userName=" + userName + ", mail=" + mail + ", password=" + password + ", address=" + address + '}';
    }
    
    
}
