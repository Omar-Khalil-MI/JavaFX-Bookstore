package com.asu.bookstore.models;

import java.time.LocalDate;

public class CreditModel extends PaymentModel {

    private String number;

    private String type;

    private LocalDate expDate;
    
    private double creditAmount;

    public CreditModel(ReaderModel reader, OrderModel order, double amount, String number, String type, LocalDate expDate, double creditAmount) {
        super(reader, order, amount);
        this.number = number;
        this.type = type;
        this.expDate = expDate;
        this.creditAmount = creditAmount;
    }

    
    @Override
    public void processPayment() {
        // Process credit card payment
        System.out.println("Processing Credit Card Payment...");
        // Credit card payment processing
        if ( creditAmount < getAmount() || expDate.compareTo(LocalDate.now()) >= 0)
            System.out.println("Credit Card Declined!");
        else System.out.println("Cash Payment Processed successfully.");
}

    

    public String getNumber() {
        return number;
    }

    public String getType() {
        return type;
    }

    public LocalDate getExpDate() {
        return expDate;
    }

    
    public boolean authorized() {
        // Check credit card authorization
        
        return true; 
    }

}
