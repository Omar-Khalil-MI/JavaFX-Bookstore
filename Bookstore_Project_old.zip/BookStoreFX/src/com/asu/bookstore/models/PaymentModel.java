package com.asu.bookstore.models;
public abstract class PaymentModel {

    private ReaderModel reader;

    private OrderModel order;

    private double amount;

    public ReaderModel getReader() {
        return reader;
    }

    public OrderModel getOrder() {
        return order;
    }

    public double getAmount() {
        return amount;
    }

    
    public PaymentModel(ReaderModel reader, OrderModel order, double amount) {
        this.reader = reader;
        this.order = order;
        this.amount = amount;
    }
    
    public abstract void processPayment();
}
