package com.asu.bookstore.main;
import com.asu.bookstore.gui.homeGUI;
import com.asu.bookstore.models.AddressModel;
import com.asu.bookstore.models.BookModel;
import com.asu.bookstore.models.InventoryModel;
import com.asu.bookstore.models.OrderModel;
import com.asu.bookstore.models.UserModel;
import com.asu.bookstore.services.DatabaseReader;
import javafx.application.Application;
import java.util.ArrayList;
import javafx.stage.Stage;

public class Main extends Application{

    /**
     *
     */
    public static final String PATH = "images/";
    public static ArrayList<BookModel> Books = new ArrayList<>();
    public static ArrayList<InventoryModel> Inventories = new ArrayList<>();
    public static ArrayList<UserModel> Users = new ArrayList<>();
    public static ArrayList<OrderModel> Orders = new ArrayList<>();
    
    public static void main(String[] args){
        AddressModel a = new AddressModel();
        DatabaseReader.loadUsers();
        DatabaseReader.loadBooks();
        DatabaseReader.loadInvent();
        System.out.println(Users.get(0).getUserName());
        
        launch(args);
    }   

    @Override
    public void start(Stage primaryStage) {
        
        homeGUI homeScene = new homeGUI();
        primaryStage.setMaximized(true);
        primaryStage.setScene(homeScene.getHomeScene());
        primaryStage.setTitle("Bookstore - Home Page");
        primaryStage.show();
    }
}

